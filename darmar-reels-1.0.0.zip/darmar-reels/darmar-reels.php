<?php
/**
 * Plugin Name: Darmar Reels
 * Description: Najnoviji i dnevni nasumični Instagram Reels, uz automatski API ili ručni unos.
 * Version: 1.0.0
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Author: Darmar Dekor
 * License: GPL-2.0-or-later
 * Text Domain: darmar-reels
 */

if (!defined('ABSPATH')) { exit; }

final class Darmar_Reels {
    const VERSION = '1.0.0';
    const SETTINGS = 'darmar_reels_settings';
    const CACHE = 'darmar_reels_cache';
    const TOKEN = 'darmar_reels_token';
    const STATUS = 'darmar_reels_status';
    const CRON = 'darmar_reels_sync';

    public static function boot() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_post_darmar_reels_save', array(__CLASS__, 'save'));
        add_action('admin_post_darmar_reels_refresh', array(__CLASS__, 'refresh_action'));
        add_action(self::CRON, array(__CLASS__, 'sync'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_init', array(__CLASS__, 'privacy'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array(__CLASS__, 'links'));
        add_shortcode('darmar_reels', array(__CLASS__, 'shortcode'));
    }

    public static function defaults() {
        return array('mode' => 'manual', 'username' => 'darmar_dekor', 'latest' => 3,
            'random' => 3, 'version' => 'v25.0', 'manual' => '', 'refresh_token' => 1,
            'title' => 'Inspiracija sa Instagrama');
    }

    public static function settings() {
        return wp_parse_args((array) get_option(self::SETTINGS, array()), self::defaults());
    }

    public static function activate($network_wide = false) {
        if ($network_wide && is_multisite()) { wp_die('Darmar Reels aktivirajte zasebno na pojedinačnom sajtu, ne na celoj mreži.'); }
        if (!wp_next_scheduled(self::CRON)) {
            wp_schedule_event(time() + 60, 'hourly', self::CRON);
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CRON);
        delete_transient('darmar_reels_lock');
    }

    public static function assets() {
        // Enqueued early so shortcode output also works in builders and widgets.
        wp_enqueue_style('darmar-reels', plugins_url('assets/reels.css', __FILE__), array(), self::VERSION);
        wp_enqueue_script('darmar-reels', plugins_url('assets/reels.js', __FILE__), array(), self::VERSION, true);
        wp_script_add_data('darmar-reels', 'strategy', 'defer');
    }

    public static function menu() {
        add_options_page('Darmar Reels', 'Darmar Reels', 'manage_options', 'darmar-reels', array(__CLASS__, 'page'));
    }

    public static function links($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=darmar-reels')) . '">Podešavanja</a>');
        return $links;
    }

    public static function privacy() {
        if (function_exists('wp_add_privacy_policy_content')) {
            wp_add_privacy_policy_content('Darmar Reels', wp_kses_post('<p>Ovaj sajt prikazuje Instagram Reels. U automatskom režimu pregledne slike učitavaju se sa Meta CDN servera (koji prima IP adresu posetioca). Instagram ugrađeni sadržaj učitava se tek kada posetilac izabere „Učitaj video”; tada važe Instagram pravila privatnosti i mogu biti postavljeni kolačići. U ručnom režimu pre klika se ne kontaktira Instagram. Server periodično kontaktira zvanični Instagram API radi osvežavanja sadržaja. Plugin nema sopstvenu analitiku.</p>'));
        }
    }

    private static function authorize($nonce) {
        if (!current_user_can('manage_options')) { wp_die('Nemate dozvolu za ovu radnju.', '', array('response' => 403)); }
        check_admin_referer($nonce);
    }

    private static function redirect($message) {
        wp_safe_redirect(add_query_arg('dr_notice', $message, admin_url('options-general.php?page=darmar-reels')));
        exit;
    }

    public static function save() {
        self::authorize('darmar_reels_save');
        $input = isset($_POST['dr']) && is_array($_POST['dr']) ? wp_unslash($_POST['dr']) : array();
        $old = self::settings();
        $new = self::defaults();
        $new['mode'] = isset($input['mode']) && $input['mode'] === 'api' ? 'api' : 'manual';
        $new['username'] = isset($input['username']) && is_string($input['username']) ? preg_replace('/[^a-zA-Z0-9_.]/', '', $input['username']) : 'darmar_dekor';
        $new['username'] = substr($new['username'], 0, 30);
        if (!$new['username']) { $new['username'] = 'darmar_dekor'; }
        foreach (array('latest', 'random') as $key) {
            $new[$key] = isset($input[$key]) && is_scalar($input[$key]) ? min(3, max(0, (int) $input[$key])) : 3;
        }
        if (!$new['latest'] && !$new['random']) { $new['latest'] = 3; }
        $version = isset($input['version']) && is_string($input['version']) ? $input['version'] : '';
        $new['version'] = preg_match('/^v\d{2}\.0$/D', $version) ? $version : 'v25.0';
        $new['title'] = isset($input['title']) && is_string($input['title']) ? sanitize_text_field($input['title']) : $new['title'];
        $new['refresh_token'] = empty($input['refresh_token']) ? 0 : 1;
        $lines = isset($input['manual']) && is_string($input['manual']) ? preg_split('/\R/', $input['manual']) : array();
        $valid = array();
        $invalid = false;
        foreach (array_slice($lines, 0, 500) as $line) {
            if (!trim($line)) { continue; }
            $url = self::reel_url(trim($line));
            if ($url) { $valid[$url] = $url; } else { $invalid = true; }
        }
        $new['manual'] = implode("\n", array_values($valid));
        $changed_token = false;
        if (!empty($input['remove_token'])) {
            delete_option(self::TOKEN);
            delete_option('darmar_reels_token_refreshed');
            $changed_token = true;
        }
        if (!empty($input['token']) && is_string($input['token'])) {
            $token = trim($input['token']);
            if (!preg_match('/^[A-Za-z0-9._|\-]+$/D', $token) || strlen($token) > 4096 || !self::store_token($token)) {
                self::redirect('token_error');
            }
            update_option('darmar_reels_token_refreshed', time(), false);
            $changed_token = true;
        }
        if ($changed_token || $old['username'] !== $new['username'] || $old['version'] !== $new['version']) {
            delete_option(self::CACHE);
            delete_option(self::STATUS);
        }
        update_option(self::SETTINGS, $new, false);
        self::activate();
        if ($new['mode'] === 'api') { self::sync(); }
        self::redirect($invalid ? 'invalid_links' : 'saved');
    }

    public static function refresh_action() {
        self::authorize('darmar_reels_refresh');
        self::sync();
        self::redirect('synced');
    }

    // Canonicalize only Reel URLs. Never accept a user-controlled iframe host.
    public static function reel_url($url) {
        if (!is_string($url) || strlen($url) > 2048) { return ''; }
        $parts = wp_parse_url($url);
        if (!$parts || empty($parts['host']) || !in_array(strtolower($parts['host']), array('instagram.com', 'www.instagram.com'), true)
            || empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https'
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['port'])) { return ''; }
        if (!preg_match('~^/reels?/([A-Za-z0-9_-]{5,80})/?$~D', isset($parts['path']) ? $parts['path'] : '', $match)) { return ''; }
        return 'https://www.instagram.com/reel/' . $match[1] . '/';
    }

    private static function store_token($token) {
        if (!function_exists('openssl_encrypt') || !function_exists('random_bytes')) { return false; }
        try { $iv = random_bytes(12); } catch (Exception $e) { return false; }
        $tag = '';
        $cipher = openssl_encrypt($token, 'aes-256-gcm', hash('sha256', wp_salt('auth'), true), OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) { return false; }
        update_option(self::TOKEN, base64_encode($iv . $tag . $cipher), false);
        return true;
    }

    private static function token() {
        if (defined('DARMAR_REELS_ACCESS_TOKEN')) { return trim((string) DARMAR_REELS_ACCESS_TOKEN); }
        if (!function_exists('openssl_decrypt')) { return ''; }
        $raw = base64_decode((string) get_option(self::TOKEN, ''), true);
        if ($raw === false || strlen($raw) < 29) { return ''; }
        $token = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', hash('sha256', wp_salt('auth'), true), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
        return is_string($token) ? $token : '';
    }

    private static function status($text, $error = true) {
        update_option(self::STATUS, array('text' => $text, 'error' => $error, 'time' => time()), false);
    }

    private static function request($path, $params, $token, $version = '') {
        $url = 'https://graph.instagram.com/' . ($version ? $version . '/' : '') . $path;
        $response = wp_remote_get(add_query_arg($params, $url), array(
            'timeout' => 12, 'redirection' => 0, 'limit_response_size' => 2 * 1024 * 1024,
            'headers' => array('Authorization' => 'Bearer ' . $token, 'Accept' => 'application/json'),
        ));
        if (is_wp_error($response)) { return new WP_Error('network', 'Instagram API nije dostupan. Proverite mrežu i pokušajte ponovo.'); }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (wp_remote_retrieve_response_code($response) !== 200 || !is_array($data) || isset($data['error'])) {
            $code = isset($data['error']['code']) ? (int) $data['error']['code'] : 0;
            // Never save or print raw API errors: they may contain credentials.
            return new WP_Error('instagram', 'Instagram API je odbio zahtev (HTTP ' . (int) wp_remote_retrieve_response_code($response) . ', kod ' . $code . '). Proverite token, dozvolu instagram_business_basic i API verziju.');
        }
        return $data;
    }

    public static function sync() {
        $s = self::settings();
        if ($s['mode'] !== 'api' || get_transient('darmar_reels_lock')) { return; }
        set_transient('darmar_reels_lock', 1, 120);
        try {
            $token = self::token();
            if (!$token) { self::status('Unesite važeći Instagram User pristupni token u podešavanjima.'); return; }
            $refresh_warning = '';
            if ($s['refresh_token'] && !defined('DARMAR_REELS_ACCESS_TOKEN') && time() - (int) get_option('darmar_reels_token_refreshed', 0) >= 7 * DAY_IN_SECONDS) {
                // This endpoint requires access_token as a query parameter, server-side only.
                $refreshed = self::request('refresh_access_token', array('grant_type' => 'ig_refresh_token', 'access_token' => $token), $token);
                if (!is_wp_error($refreshed) && !empty($refreshed['access_token']) && self::store_token($refreshed['access_token'])) {
                    $token = $refreshed['access_token'];
                    update_option('darmar_reels_token_refreshed', time(), false);
                } else {
                    $refresh_warning = ' Automatsko obnavljanje tokena nije uspelo; proverite dugoročni token.';
                }
            }
            $profile = self::request('me', array('fields' => 'user_id,username'), $token, $s['version']);
            if (is_wp_error($profile)) { self::status($profile->get_error_message()); return; }
            if (empty($profile['username']) || strcasecmp($profile['username'], $s['username']) !== 0) {
                self::status('Token ne pripada podešenom Instagram korisniku. Proverite korisničko ime i token.'); return;
            }
            $id = isset($profile['user_id']) ? (string) $profile['user_id'] : '';
            if (!preg_match('/^\d+$/D', $id)) { self::status('Instagram nije vratio ispravan ID naloga.'); return; }
            $items = array();
            $after = '';
            $partial = false;
            for ($page = 0; $page < 5; $page++) {
                $params = array('fields' => 'id,media_type,permalink,thumbnail_url,timestamp', 'limit' => 100);
                if ($after) { $params['after'] = $after; }
                $data = self::request($id . '/media', $params, $token, $s['version']);
                if (is_wp_error($data) || !isset($data['data']) || !is_array($data['data'])) {
                    self::status(is_wp_error($data) ? $data->get_error_message() : 'Instagram je vratio neispravan odgovor.');
                    return; // Keep last successful cache on any failed page.
                }
                foreach ($data['data'] as $media) {
                    $url = self::reel_url(isset($media['permalink']) ? $media['permalink'] : '');
                    $timestamp = isset($media['timestamp']) ? strtotime($media['timestamp']) : false;
                    if (!$url || !$timestamp || !isset($media['media_type']) || $media['media_type'] !== 'VIDEO') { continue; }
                    $items[$url] = array('url' => $url, 'timestamp' => $timestamp,
                        'thumbnail' => self::thumbnail_url(isset($media['thumbnail_url']) ? $media['thumbnail_url'] : ''));
                }
                $next = isset($data['paging']['cursors']['after']) ? (string) $data['paging']['cursors']['after'] : '';
                if (empty($data['paging']['next']) || !$next || $next === $after) { break; }
                // Follow only the cursor, never an API-supplied URL or host.
                $after = $next;
                $partial = ($page === 4);
            }
            $items = array_values($items);
            usort($items, static function ($a, $b) {
                return $b['timestamp'] <=> $a['timestamp'] ?: strcmp($a['url'], $b['url']);
            });
            update_option(self::CACHE, array('items' => $items, 'time' => time(), 'username' => $s['username'], 'version' => $s['version'],
                'source' => defined('DARMAR_REELS_ACCESS_TOKEN') ? wp_hash((string) DARMAR_REELS_ACCESS_TOKEN) : ''), false);
            self::status('Sinhronizovano Reelsa: ' . count($items) . ($partial ? '. Izbor obuhvata najviše 500 poslednjih objava.' : '.') . $refresh_warning, (bool) $refresh_warning);
        } finally {
            delete_transient('darmar_reels_lock');
        }
    }

    private static function thumbnail_url($url) {
        $parts = is_string($url) ? wp_parse_url($url) : false;
        if (!$parts || empty($parts['scheme']) || $parts['scheme'] !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['port'])) { return ''; }
        // Thumbnail destinations are restricted to Meta's CDN domains.
        if (!preg_match('/(^|\.)(cdninstagram\.com|fbcdn\.net)$/iD', $parts['host'])) { return ''; }
        return esc_url_raw($url, array('https'));
    }

    public static function items() {
        $s = self::settings();
        if ($s['mode'] === 'manual') {
            $items = array();
            foreach (preg_split('/\R/', $s['manual']) as $line) {
                $url = self::reel_url(trim($line));
                if ($url) { $items[$url] = array('url' => $url, 'timestamp' => 0, 'thumbnail' => ''); }
            }
            return array_values($items);
        }
        $cache = get_option(self::CACHE, array());
        $source = defined('DARMAR_REELS_ACCESS_TOKEN') ? wp_hash((string) DARMAR_REELS_ACCESS_TOKEN) : '';
        if (empty($cache['time']) || time() - $cache['time'] > 2 * DAY_IN_SECONDS
            || !isset($cache['source']) || !hash_equals($cache['source'], $source)
            || !isset($cache['username'], $cache['version']) || $cache['username'] !== $s['username'] || $cache['version'] !== $s['version']) { return array(); }
        return isset($cache['items']) && is_array($cache['items']) ? $cache['items'] : array();
    }

    public static function select($items, $latest, $random, $seed) {
        $latest = min(3, max(0, (int) $latest));
        $random = min(3, max(0, (int) $random));
        $newest = array_slice($items, 0, $latest);
        $older = array_slice($items, $latest);
        // Stable during a site-local day; no global PRNG side effects.
        usort($older, static function ($a, $b) use ($seed) {
            return strcmp(hash('sha256', $seed . $a['url']), hash('sha256', $seed . $b['url']));
        });
        return array('latest' => $newest, 'random' => array_slice($older, 0, $random));
    }

    public static function shortcode($atts = array()) {
        $s = self::settings();
        $atts = shortcode_atts(array('latest' => $s['latest'], 'random' => $s['random'], 'title' => $s['title']), $atts, 'darmar_reels');
        $items = self::items();
        if (!$items) {
            return current_user_can('manage_options') ? '<p class="dr-empty">Darmar Reels: dodajte linkove ili povežite API u Podešavanja → Darmar Reels. Ako je API povezan, proverite status sinhronizacije.</p>' : '';
        }
        $groups = self::select($items, $atts['latest'], $atts['random'], wp_date('Y-m-d') . '|' . $s['username']);
        if (!$groups['latest'] && !$groups['random']) { return ''; }
        ob_start();
        ?>
        <section class="dr-reels" aria-label="Instagram Reels">
            <div class="dr-header">
                <div><p class="dr-eyebrow">DARMAR DEKOR · REELS</p>
                <?php if ($atts['title'] !== '') : ?><h2 class="dr-title"><?php echo esc_html($atts['title']); ?></h2><?php endif; ?></div>
                <a class="dr-profile" href="<?php echo esc_url('https://www.instagram.com/' . $s['username'] . '/'); ?>" target="_blank" rel="noopener noreferrer">@<?php echo esc_html($s['username']); ?> <svg class="dr-external" aria-hidden="true" viewBox="0 0 16 16" width="12" height="12"><path d="M4 12 12 4M4 4h8v8" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></a>
            </div>
            <?php foreach ($groups as $key => $group) : if (!$group) { continue; } ?>
                <h3 class="dr-group-title"><?php echo $key === 'latest' ? 'Najnovije inspiracije' : 'Još ideja za vaš prostor'; ?></h3>
                <div class="dr-grid">
                <?php foreach ($group as $index => $item) :
                    $url = self::reel_url($item['url']);
                    if (!$url) { continue; }
                    $label = ($key === 'latest' ? 'Najnoviji Reel ' : 'Reel iz izbora ') . ($index + 1);
                    $thumbnail = self::thumbnail_url(isset($item['thumbnail']) ? $item['thumbnail'] : ''); ?>
                    <article class="dr-card">
                        <div class="dr-media">
                            <a class="dr-load" href="<?php echo esc_url($url); ?>" data-dr-embed="<?php echo esc_url($url . 'embed/'); ?>" aria-label="<?php echo esc_attr('Učitaj video: ' . $label . '. Povezivanje sa Instagramom.'); ?>" target="_blank" rel="noopener noreferrer">
                                <?php if ($thumbnail) : ?><img class="dr-thumb" src="<?php echo esc_url($thumbnail); ?>" alt="" loading="lazy" decoding="async" width="360" height="640" referrerpolicy="no-referrer"><?php endif; ?>
                                <span class="dr-placeholder" aria-hidden="true"><span>DARMAR</span><small>DEKOR</small></span>
                                <span class="dr-play" aria-hidden="true"></span><span class="dr-load-label">Učitaj video</span>
                            </a>
                        </div>
                        <div class="dr-card-footer"><span><?php echo esc_html($label); ?></span><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($label . ' — otvori na Instagramu'); ?>">Instagram <svg class="dr-external" aria-hidden="true" viewBox="0 0 16 16" width="12" height="12"><path d="M4 12 12 4M4 4h8v8" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></a></div>
                    </article>
                <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            <p class="dr-note">Klikom na „Učitaj video” učitavate sadržaj sa Instagrama. Ako video nije dostupan, otvorite ga na Instagramu.</p>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        $s = self::settings();
        $status = get_option(self::STATUS, array());
        $cache = get_option(self::CACHE, array());
        $notices = array('saved' => 'Podešavanja su sačuvana.', 'synced' => 'Pokušaj osvežavanja je završen. Proverite status ispod.',
            'invalid_links' => 'Sačuvano. Neispravni linkovi su preskočeni; koristite https://www.instagram.com/reel/KOD/.',
            'token_error' => 'Token nije sačuvan. Proverite format i dostupnost PHP OpenSSL podrške.');
        $notice = isset($_GET['dr_notice']) && is_string($_GET['dr_notice']) ? sanitize_key(wp_unslash($_GET['dr_notice'])) : '';
        ?>
        <div class="wrap"><h1>Darmar Reels</h1>
            <?php if (isset($notices[$notice])) : ?><div class="notice notice-info"><p><?php echo esc_html($notices[$notice]); ?></p></div><?php endif; ?>
            <p>Na početnu stranicu dodajte Shortcode blok (ili Elementor Shortcode widget): <code>[darmar_reels]</code></p>
            <p>Podrazumevano: 3 najnovija + 3 nasumična starija Reelsa. Nasumični izbor se menja dnevno prema vremenskoj zoni WordPressa.</p>
            <?php if ($status) : ?><div class="notice <?php echo !empty($status['error']) ? 'notice-warning' : 'notice-success'; ?> inline"><p><?php echo esc_html($status['text']); ?> <small>(<?php echo esc_html(wp_date('d.m.Y. H:i', $status['time'])); ?>)</small></p></div><?php endif; ?>
            <?php if (!empty($cache['time'])) : ?><p>Poslednja uspešna sinhronizacija: <?php echo esc_html(wp_date('d.m.Y. H:i', $cache['time'])); ?>. U kešu: <?php echo (int) count($cache['items']); ?> Reelsa.</p><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="darmar_reels_save"><?php wp_nonce_field('darmar_reels_save'); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="dr-mode">Izvor sadržaja</label></th><td><select id="dr-mode" name="dr[mode]"><option value="manual" <?php selected($s['mode'], 'manual'); ?>>Ručni unos linkova</option><option value="api" <?php selected($s['mode'], 'api'); ?>>Automatski — Instagram API</option></select></td></tr>
                    <tr><th scope="row"><label for="dr-username">Instagram korisničko ime</label></th><td><input id="dr-username" name="dr[username]" value="<?php echo esc_attr($s['username']); ?>" maxlength="30" class="regular-text"><p class="description">Bez @. U API režimu mora odgovarati nalogu koji je izdao token.</p></td></tr>
                    <tr><th scope="row"><label for="dr-title">Naslov sekcije</label></th><td><input id="dr-title" name="dr[title]" value="<?php echo esc_attr($s['title']); ?>" class="regular-text"></td></tr>
                    <tr><th scope="row">Broj videa</th><td><label>Najnoviji <input aria-label="Broj najnovijih" type="number" min="0" max="3" name="dr[latest]" value="<?php echo (int) $s['latest']; ?>"></label> <label>Nasumični <input aria-label="Broj nasumičnih" type="number" min="0" max="3" name="dr[random]" value="<?php echo (int) $s['random']; ?>"></label><p class="description">0–3 po grupi. Ako nema dovoljno snimaka, prikazaće se manje, bez ponavljanja.</p></td></tr>
                    <tr><th scope="row"><label for="dr-manual">Ručni linkovi</label></th><td><textarea id="dr-manual" name="dr[manual]" rows="10" class="large-text code"><?php echo esc_textarea($s['manual']); ?></textarea><p class="description">Jedan Reel link po redu, najnoviji na vrhu (do 500). Ovaj redosled određuje „najnovije” u ručnom režimu. Vlasništvo linkova se ne proverava; unosite svoje Reelse.</p></td></tr>
                    <tr><th scope="row"><label for="dr-token">Instagram User token</label></th><td><input type="password" id="dr-token" name="dr[token]" value="" class="large-text" autocomplete="new-password" spellcheck="false"><p class="description"><?php echo self::token() ? 'Token je podešen. Prazno polje zadržava postojeći token.' : 'Token nije podešen.'; ?> Unesite dugoročni token za Instagram API with Instagram Login, sa dozvolom instagram_business_basic. Ovo nije Instagram lozinka i nije stari Basic Display token.</p><label><input type="checkbox" name="dr[remove_token]" value="1"> Obriši sačuvani token</label><?php if (defined('DARMAR_REELS_ACCESS_TOKEN')) : ?><p>Aktivna je konstanta DARMAR_REELS_ACCESS_TOKEN iz wp-config.php. Ona ima prednost i održava se ručno.</p><?php endif; ?></td></tr>
                    <tr><th scope="row"><label for="dr-version">Meta API verzija</label></th><td><input id="dr-version" name="dr[version]" value="<?php echo esc_attr($s['version']); ?>" pattern="v[0-9]{2}\.0"><p class="description">Podrazumevano v25.0. Promenite samo u verziju koju podržava vaša Meta aplikacija.</p></td></tr>
                    <tr><th scope="row">Obnavljanje tokena</th><td><label><input type="checkbox" name="dr[refresh_token]" value="1" <?php checked($s['refresh_token'], 1); ?>> Automatski pokušaj obnavljanja dugoročnog tokena svakih 7 dana</label><p class="description">Token mora već biti dugoročni i neistekao. Istekao ili opozvan token zahteva ponovno povezivanje. Za token iz wp-config.php automatsko obnavljanje je isključeno.</p></td></tr>
                </table>
                <?php submit_button('Sačuvaj podešavanja'); ?>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="darmar_reels_refresh"><?php wp_nonce_field('darmar_reels_refresh'); submit_button('Osveži Instagram sada', 'secondary'); ?></form>
            <h2>Kako uključiti automatski režim</h2>
            <ol><li>U Meta for Developers napravite aplikaciju sa Instagram API with Instagram Login i dodajte svoj Business nalog kao dozvoljeni/test nalog; prihvatite poziv ako se traži.</li><li>U Instagram API setup delu aplikacije generišite Instagram User token sa dozvolom <code>instagram_business_basic</code>. Koristite dugoročni token; ako je izdat kratkoročni, zamenite ga za dugoročni po Meta uputstvu.</li><li>Unesite token ovde preko HTTPS veze, izaberite automatski režim i sačuvajte. Proverite status i broj pronađenih Reelsa.</li></ol>
            <p>Plugin koristi vaš token; ne sadrži zajedničku Meta aplikaciju ni dugme za povezivanje jednim klikom. Facebook stranica nije potrebna za ovu Instagram Login integraciju. Ako aplikaciju koriste nalozi bez uloge u aplikaciji, Meta može zahtevati App Review / Advanced Access.</p>
            <p><a href="https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/" target="_blank" rel="noopener noreferrer">Zvanična Meta dokumentacija</a> · Detaljno uputstvo je u fajlu <code>UPUTSTVO.md</code> u ZIP paketu.</p>
            <p>Osvežavanje se pokreće preko WP-Cron jednom na sat. Za pouzdan raspored uključite serverski cron. Keš početne stranice podesite na najviše jedan sat. Pregledne slike kontaktiraju Meta CDN; Instagram embed se učitava tek klikom. Proverite tekst u Podešavanja → Privatnost.</p>
        </div>
        <?php
    }
}

Darmar_Reels::boot();
register_activation_hook(__FILE__, array('Darmar_Reels', 'activate'));
register_deactivation_hook(__FILE__, array('Darmar_Reels', 'deactivate'));
