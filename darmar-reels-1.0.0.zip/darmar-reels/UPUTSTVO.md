# Darmar Reels 1.0.0

Namenski WordPress plugin za darmardekor.rs i @darmar_dekor. Bez pretplate, bez scraping-a, bez biblioteka koje se učitavaju sa trećih strana. Izvorni kod je uključen, licenca GPL-2.0-or-later.

## Instalacija

1. U WordPress administraciji otvorite **Dodaci → Dodaj novi → Otpremi dodatak**.
2. Izaberite `darmar-reels-1.0.0.zip`, instalirajte i aktivirajte.
3. Otvorite **Podešavanja → Darmar Reels**.
4. Na početnu stranicu dodajte **Shortcode** blok sa `[darmar_reels]`. Elementor: Shortcode widget. Gutenberg: Shortcode blok. WPBakery: Text Block sa shortcodeom. Sačuvajte stranicu i očistite njen keš.

Zahtevi: WordPress 6.3+, PHP 7.4+ (preporučena aktuelna podržana PHP verzija), jedan WordPress sajt. Za čuvanje tokena u bazi potrebna je PHP OpenSSL ekstenzija. Za API su potrebni HTTPS, dozvoljeni odlazni HTTPS zahtevi ka graph.instagram.com i ispravan WordPress cron. Mrežna aktivacija na multisite instalaciji nije podržana; aktivirajte zasebno na pojedinačnom sajtu.

## Brzi početak bez Meta aplikacije

Izaberite **Ručni unos linkova**. Kopirajte linkove svojih Reelsa, jedan po redu, **najnoviji na vrhu**. Sačuvajte. Minimum za pun prikaz 3 + 3 je šest različitih Reelsa. Plugin uklanja duplikate i parametre deljenja iz linkova. Prihvata isključivo HTTPS linkove oblika `https://www.instagram.com/reel/KOD/` (ili `/reels/KOD/`).

U ovom režimu „najnoviji” znači prva tri linka u listi — datum objave se ne preuzima. Nema automatskih preglednih slika; umesto njih prikazuje se neutralna Darmar kartica. Klik učitava Instagram embed, a zaseban link uvek otvara original. Novi linkovi se dodaju ručno. Plugin ne proverava vlasništvo ručno dodatih linkova.

## Automatski režim za Business nalog

Ovaj ZIP **ne sadrži registrovanu zajedničku Meta aplikaciju ni povezivanje jednim klikom**. Za automatski rad potrebna je vaša Meta aplikacija i Instagram User pristupni token. Instagram lozinka se nigde ne unosi u plugin.

1. Otvorite [Meta for Developers](https://developers.facebook.com/apps/), kreirajte aplikaciju i podesite **Instagram API with Instagram Login**. Nemojte koristiti povučeni Instagram Basic Display API niti Facebook Page token u ovom pluginu.
2. U podešavanju Instagram API-ja dodajte @darmar_dekor kao svoj/test nalog i prihvatite poziv na Instagramu ako se traži. Business nalog je odgovarajući tip. Instagram Login putanja ne zahteva povezanu Facebook stranicu.
3. U delu za generisanje pristupnih tokena autorizujte nalog sa dozvolom **instagram_business_basic**. Ne traže se dozvole za objavljivanje, poruke ili komentare.
4. Koristite **dugoročni Instagram User access token**. Ako Meta izda kratkoročni token, prvo ga zamenite za dugoročni prema zvaničnom uputstvu (server-side exchange, sa vašim app secretom). Plugin namerno ne traži i ne čuva app secret. Izgled i koraci Meta kontrolne table mogu se menjati.
5. U **Podešavanja → Darmar Reels** izaberite automatski režim, unesite korisničko ime `darmar_dekor` i token, pa sačuvajte. Token unosite samo preko HTTPS administracije. Ne šaljite ga u čet i ne stavljajte u javni HTML.
6. Proverite status sinhronizacije i broj pronađenih Reelsa. Ako je potrebno, pritisnite **Osveži Instagram sada**. Ako nema snimaka, proverite dozvole, tip tokena i linkove koje API vraća.

Za vlastiti nalog sa odgovarajućom ulogom u aplikaciji obično se koristi pristup predviđen za naloge aplikacije. Za naloge izvan tih uloga Meta može zahtevati Advanced Access / App Review i dodatnu verifikaciju. Business status sam po sebi ne garantuje odobren pristup.

Dokumentacija:

- [Instagram API with Instagram Login](https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login/)
- [Dugoročni tokeni](https://developers.facebook.com/docs/instagram-platform/reference/access_token/)
- [Obnavljanje tokena](https://developers.facebook.com/docs/instagram-platform/reference/refresh_access_token/)
- [Zvanična Meta Instagram API kolekcija](https://www.postman.com/meta/instagram/overview)

## Šta se prikazuje

- Podrazumevano tri najnovija Reelsa i tri nasumična iz preostalih snimaka, bez ponavljanja.
- Broj u svakoj grupi može biti 0–3; u podešavanjima bar jedna grupa mora biti uključena.
- Automatski režim sortira po API datumu objavljivanja. Uzimaju se VIDEO objave sa `/reel/` ili `/reels/` permalinkom; fotografije, carouseli i Stories se preskaču.
- Pregleda se najviše **500 poslednjih objava koje API vrati** (pet strana po 100), ne nužno cela istorija naloga. Nasumični izbor je iz pronađenih Reelsa u tom skupu. Zbog Meta ograničenja neke objave mogu izostati.
- Dnevni izbor koristi WordPress vremensku zonu. Može slučajno biti isti i narednog dana; ne čuva se istorija prethodnih izbora.
- Ako nema šest snimaka, prikazuje se manje kartica. Ne dodaju se lažni primeri. Bez sadržaja se sekcija skriva posetiocima, a administrator vidi poruku.
- Grupe se prilagođavaju telefonu. Instagram embed se učitava tek klikom; otvaranje u aplikaciji / novoj kartici radi i bez JavaScripta.
- Embed zavisi od javne dostupnosti objave, Instagram dozvole za ugrađivanje, kolačića i podešavanja pregledača. Može prikazati Instagram interfejs ili zahtev za prijavu. Ako je blokiran, koristite link „Instagram ↗”. Plugin ne uklanja Instagram brendiranje.

Opcioni shortcode:

```text
[darmar_reels latest="2" random="2" title="Ideje za vaš dom"]
```

Za prilagođavanje boja iz teme:

```css
.dr-reels {
  --dr-ink: #302c28;
  --dr-muted: #746b61;
  --dr-sand: #f4efe8;
  --dr-accent: #9a704b;
}
```

## Keš, cron i token

Podaci se osvežavaju jednom na sat pomoću WP-Cron. Posetilac ne pokreće API zahteve; čita se lokalni keš. Čuvaju se permalink, datum i pregledna slika, a ne kopije video-fajlova. Kod neuspešne sinhronizacije poslednji uspešan sadržaj ostaje do 48 sati, posle čega se sekcija skriva. Instagram pregledne slike mogu isteći i ranije. Ručno uneseni linkovi ne ističu po ovom pravilu. API greška ne prebacuje automatski na ručni režim: administrator može sam promeniti izvor.

WordPress cron zavisi od poseta. Za pouzdan rad podesite serverski cron prema uputstvu hostinga, npr. na pet minuta. Ako koristite dodatak za keširanje/CDN, podesite trajanje keša početne na najviše jedan sat i obrišite keš posle izmene shortcodea ili podešavanja. Plugin ne briše keš drugih dodataka. Bez toga dnevni izbor i novi snimci mogu kasniti.

Automatsko obnavljanje pokušava se svakih sedam dana pri sinhronizaciji. Radi samo sa važećim dugoročnim Instagram tokenima koji ispunjavaju Meta uslove. Ne može oživeti istekao ili opozvan token. U tom slučaju generišite novi token i unesite ga ponovo. Administracija prikazuje status i vreme poslednjeg uspeha, ali plugin ne šalje obaveštenja e-poštom.

Token iz administracije čuva se šifrovano AES-256-GCM ključem izvedenim iz WordPress auth salt vrednosti, u opciji bez autoload-a. Polje nikad ne prikazuje sačuvani token. Administratori/hosting koji imaju pristup i bazi i wp-config.php i dalje mogu dešifrovati token. Promena WordPress salt vrednosti zahteva ponovni unos tokena. Standardni API zahtevi koriste Authorization zaglavlje; zvanični endpoint za obnovu prima token u URL parametru samo sa serverske strane. Redigujte access_token u HTTP debug alatima i proxy logovima ako ih uključujete.

Napredna alternativa: definišite `DARMAR_REELS_ACCESS_TOKEN` u wp-config.php (pre WordPress bootstrap-a). Konstanta ima prednost nad bazom; plugin je ne menja niti automatski obnavlja. Posle promene konstante pokrenite „Osveži Instagram sada”; stari keš biće sakriven dok nova sinhronizacija ne uspe. Preporučuje se uobičajeni unos kroz administraciju.

## Privatnost i uklanjanje

U API režimu pregledne slike učitavaju se sa Meta CDN-a i šalju IP adresu posetioca tom servisu. Ugrađeni Instagram sadržaj učitava se tek klikom posetioca i tada može postaviti kolačiće. Ručni režim pre klika ne učitava Instagram resurse. Prilagodite politiku privatnosti sajta i postojeći sistem upravljanja saglasnošću. Predloženi tekst dostupan je u WordPress alatu za politiku privatnosti. Plugin nema sopstveno praćenje posetilaca.

Deaktivacija zaustavlja cron, a čuva podešavanja. Brisanje plugina kroz WordPress uklanja podešavanja, šifrovani token, status i lokalni keš; ne briše Instagram objave. Token definisan u wp-config.php treba zasebno ukloniti. Opoziv pristupa Meta aplikaciji radi se u Meta/Instagram podešavanjima naloga.

## Provera pre puštanja

Instalirajte prvo na probnu kopiju sajta i proverite prikaz u svojoj temi na telefonu i računaru, ručni režim sa stvarnim linkovima, pa API režim sa tokenom @darmar_dekor. U ovom paketu nema vašeg tokena niti privatnih podataka. Automatska integracija sa vašim nalogom i izgled na darmardekor.rs mogu se potvrditi tek nakon povezivanja i instalacije.
