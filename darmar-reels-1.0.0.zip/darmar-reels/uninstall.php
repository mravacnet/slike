<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Multisite network activation is intentionally not supported in this release.
foreach (array('darmar_reels_settings', 'darmar_reels_cache', 'darmar_reels_token', 'darmar_reels_status', 'darmar_reels_token_refreshed') as $option) {
    delete_option($option);
}
wp_clear_scheduled_hook('darmar_reels_sync');
delete_transient('darmar_reels_lock');
