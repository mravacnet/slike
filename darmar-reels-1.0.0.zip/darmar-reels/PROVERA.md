# Provera paketa 1.0.0

Plugin je instaliran i aktiviran u lokalnom WordPress Playground okruženju, sa stvarnim WordPress funkcijama i SQLite bazom.

- WordPress 6.8.12 / PHP 8.3.36: 50 uspešnih provera.
- WordPress 6.8.12 / PHP 7.4.34-dev: istih 50 uspešnih provera radi kompatibilnosti sintakse i funkcija.
- Chromium / Playwright: 8 uspešnih provera prikaza i interakcija, uključujući širine 320, 390, 600 i 768 piksela, učitavanje jednog embed-a na Enter i linkove bez JavaScripta.
- PHP i JavaScript sintaksa proverene. ZIP proveren na oštećenje i strukturu.

Provere pokrivaju aktivaciju i cron, ručne linkove i duplikate, bezbedne URL-ove, izbor najnovijih i nasumičnih snimaka bez preklapanja, escape naslova, prazan sadržaj, šifrovanje i obnavljanje tokena, paginaciju i sortiranje API podataka, status grešaka bez otkrivanja tokena, keš u slučaju greške, istek keša, deaktivaciju i uklanjanje podataka pri brisanju.

API odgovori su simulirani kroz WordPress HTTP filter. Testovi ne potvrđuju pristup stvarnom @darmar_dekor nalogu, aktuelne dozvole vaše Meta aplikacije, reprodukciju stvarnih Instagram videa ni izgled u temi na darmardekor.rs. Te provere zahtevaju instalaciju i autorizaciju naloga. Na javnom sajtu ništa nije menjano.
