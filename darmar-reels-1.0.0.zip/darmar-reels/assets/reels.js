(function () {
    'use strict';
    document.addEventListener('click', function (event) {
        var trigger = event.target.closest ? event.target.closest('.dr-load[data-dr-embed]') : null;
        if (!trigger || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || event.button > 0) return;
        var source = trigger.getAttribute('data-dr-embed');
        if (!/^https:\/\/www\.instagram\.com\/reel\/[A-Za-z0-9_-]{5,80}\/embed\/$/.test(source)) return;
        event.preventDefault();
        var frame = document.createElement('iframe');
        frame.className = 'dr-iframe';
        frame.src = source;
        frame.title = trigger.getAttribute('aria-label').replace('Učitaj video: ', 'Instagram: ');
        frame.allow = 'encrypted-media; fullscreen; picture-in-picture';
        frame.allowFullscreen = true;
        frame.referrerPolicy = 'strict-origin-when-cross-origin';
        frame.setAttribute('tabindex', '0');
        trigger.replaceWith(frame);
        frame.focus();
    });
}());
