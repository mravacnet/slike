=== Darmar Reels ===
Requires at least: 6.3
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Latest and daily random Instagram Reels for Darmar Dekor. Serbian admin and frontend.

== Description ==
Display up to three latest and three non-overlapping daily random Reels.
Manual URL mode works without API credentials. Automatic mode requires your own
Meta app and a long-lived Instagram User access token with instagram_business_basic.
No shared OAuth app or one-click authorization service is included.

Instagram Graph API and Meta CDN / Instagram embeds are external services.
Only API mode makes scheduled server-side requests. Thumbnail requests go to Meta
CDN when cards are displayed. Instagram iframes are loaded only on user click.
Terms: https://help.instagram.com/581066165581870/
Privacy: https://privacycenter.instagram.com/policy/
Full Serbian setup, limitations, token security, cron and cache guidance: UPUTSTVO.md.

== Installation ==
Upload ZIP in Plugins > Add New. Activate on an individual site.
Settings > Darmar Reels. Add [darmar_reels] to your homepage.
Network-wide multisite activation is not supported.

== Changelog ==
= 1.0.0 =
Initial release.
